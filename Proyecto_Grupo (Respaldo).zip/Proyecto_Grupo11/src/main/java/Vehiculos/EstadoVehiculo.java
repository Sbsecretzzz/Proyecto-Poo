/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vehiculos;

/**
 *
 * @author Leonardo
 */
public enum EstadoVehiculo {
    DISPONIBLE,
    RESERVADO,
    VENDIDO
}
//Reemplaza el texto del String para controlar el estado del auto en los 3 estados fijos que podra controlar el adminsitrador