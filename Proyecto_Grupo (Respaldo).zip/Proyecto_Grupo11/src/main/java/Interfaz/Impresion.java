/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Interfaz;

/**
 *
 * @author sebas
 */
//Nos permite generar reportes del texto para las clases vehiculo y ventas , facilitara para la parte del GUI
//Nos permite realizar una herenccia multiple si importar las herencias como se vio
public interface Impresion {
    public String generarImpresion();
    
}
